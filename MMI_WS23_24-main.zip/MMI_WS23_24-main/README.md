# MMI_WS23_24

Demo Project for MMI WS 23/24. We will use this project to apply theoretical knowledge (e.g. versioning via Git, Refactoring, Unit Tests, Usability Tests)